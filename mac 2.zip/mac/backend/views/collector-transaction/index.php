<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel backend\models\CollectorTransactionSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Collector Transactions';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="collector-transaction-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a('Create Collector Transaction', ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'id',
            'collector_id',
            'consumer_id',
            'date_time',
            'amount',
            //'receipt_number',
            //'supervisor_id',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
</div>

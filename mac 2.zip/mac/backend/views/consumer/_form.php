<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model backend\models\Consumer */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="consumer-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'name')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'address')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'phone_number')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'email')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'user_id')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'collector_id')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'current_bill')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'adjustment')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'total_amount_to_be_paid')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'total_amount_paid')->textInput(['maxlength' => true]) ?>

    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>

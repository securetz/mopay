<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model backend\models\CollectorConsumerTransaction */

$this->title = 'Create Collector Consumer Transaction';
$this->params['breadcrumbs'][] = ['label' => 'Collector Consumer Transactions', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="collector-consumer-transaction-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>

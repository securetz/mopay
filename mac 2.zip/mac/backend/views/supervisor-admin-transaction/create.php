<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model backend\models\SupervisorAdminTransaction */

$this->title = 'Create Supervisor Admin Transaction';
$this->params['breadcrumbs'][] = ['label' => 'Supervisor Admin Transactions', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="supervisor-admin-transaction-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>

<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "supervisor_collector_transaction".
 *
 * @property int $id
 * @property string $supervisor_id
 * @property string $collector_id
 * @property string $date_time
 * @property string $amount
 */
class SupervisorCollectorTransaction extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'supervisor_collector_transaction';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['supervisor_id', 'collector_id', 'date_time', 'amount'], 'required'],
            [['supervisor_id', 'collector_id', 'date_time', 'amount'], 'string', 'max' => 255],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'supervisor_id' => 'Supervisor ID',
            'collector_id' => 'Collector ID',
            'date_time' => 'Date Time',
            'amount' => 'Amount',
        ];
    }
}

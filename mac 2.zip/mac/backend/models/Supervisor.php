<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "supervisor".
 *
 * @property int $id
 * @property string $name
 * @property string $address
 * @property string $phone_number
 * @property string $user_id
 * @property string $password
 * @property string $cash_in_hand
 */
class Supervisor extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'supervisor';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['name', 'phone_number', 'user_id', 'password', 'cash_in_hand'], 'required'],
            [['name', 'address', 'phone_number', 'user_id', 'password', 'cash_in_hand'], 'string', 'max' => 255],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Name',
            'address' => 'Address',
            'phone_number' => 'Phone Number',
            'user_id' => 'User ID',
            'password' => 'Password',
            'cash_in_hand' => 'Cash In Hand',
        ];
    }
}

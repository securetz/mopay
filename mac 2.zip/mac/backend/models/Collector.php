<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "collector".
 *
 * @property int $id
 * @property string $name
 * @property string $address
 * @property string $phone_number
 * @property string $email
 * @property string $user_id
 * @property string $supervisor_id
 * @property string $password
 * @property string $cash_in_hand
 */
class Collector extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'collector';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['name', 'address', 'phone_number', 'email', 'user_id', 'supervisor_id', 'password', 'cash_in_hand'], 'required'],
            [['name', 'address', 'phone_number', 'email', 'user_id', 'supervisor_id', 'password', 'cash_in_hand'], 'string', 'max' => 255],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Name',
            'address' => 'Address',
            'phone_number' => 'Phone Number',
            'email' => 'Email',
            'user_id' => 'User ID',
            'supervisor_id' => 'Supervisor ID',
            'password' => 'Password',
            'cash_in_hand' => 'Cash In Hand',
        ];
    }
}

<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "collector_transaction".
 *
 * @property int $id
 * @property string $collector_id
 * @property string $consumer_id
 * @property string $date_time
 * @property string $amount
 * @property string $receipt_number
 * @property string $supervisor_id
 */
class CollectorTransaction extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'collector_transaction';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['collector_id', 'consumer_id', 'date_time', 'amount', 'receipt_number', 'supervisor_id'], 'required'],
            [['collector_id', 'consumer_id', 'date_time', 'amount', 'receipt_number', 'supervisor_id'], 'string', 'max' => 255],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'collector_id' => 'Collector ID',
            'consumer_id' => 'Consumer ID',
            'date_time' => 'Date Time',
            'amount' => 'Amount',
            'receipt_number' => 'Receipt Number',
            'supervisor_id' => 'Supervisor ID',
        ];
    }
}

<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "consumer".
 *
 * @property int $id
 * @property string $name
 * @property string $address
 * @property string $phone_number
 * @property string $email
 * @property string $user_id
 * @property string $collector_id
 * @property string $current_bill
 * @property string $adjustment
 * @property string $total_amount_to_be_paid
 * @property string $total_amount_paid
 */
class Consumer extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'consumer';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['name', 'user_id'], 'required'],
            [['name', 'address', 'phone_number', 'email', 'user_id', 'collector_id', 'current_bill', 'adjustment', 'total_amount_to_be_paid', 'total_amount_paid'], 'string', 'max' => 255],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Name',
            'address' => 'Address',
            'phone_number' => 'Phone Number',
            'email' => 'Email',
            'user_id' => 'User ID',
            'collector_id' => 'Collector ID',
            'current_bill' => 'Current Bill',
            'adjustment' => 'Adjustment',
            'total_amount_to_be_paid' => 'Total Amount To Be Paid',
            'total_amount_paid' => 'Total Amount Paid',
        ];
    }
}

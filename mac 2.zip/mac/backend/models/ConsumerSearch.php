<?php

namespace backend\models;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use backend\models\Consumer;

/**
 * ConsumerSearch represents the model behind the search form of `backend\models\Consumer`.
 */
class ConsumerSearch extends Consumer
{
    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['id'], 'integer'],
            [['name', 'address', 'phone_number', 'email', 'user_id', 'collector_id', 'current_bill', 'adjustment', 'total_amount_to_be_paid', 'total_amount_paid'], 'safe'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = Consumer::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'id' => $this->id,
        ]);

        $query->andFilterWhere(['like', 'name', $this->name])
            ->andFilterWhere(['like', 'address', $this->address])
            ->andFilterWhere(['like', 'phone_number', $this->phone_number])
            ->andFilterWhere(['like', 'email', $this->email])
            ->andFilterWhere(['like', 'user_id', $this->user_id])
            ->andFilterWhere(['like', 'collector_id', $this->collector_id])
            ->andFilterWhere(['like', 'current_bill', $this->current_bill])
            ->andFilterWhere(['like', 'adjustment', $this->adjustment])
            ->andFilterWhere(['like', 'total_amount_to_be_paid', $this->total_amount_to_be_paid])
            ->andFilterWhere(['like', 'total_amount_paid', $this->total_amount_paid]);

        return $dataProvider;
    }
}

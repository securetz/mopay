<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "Admin".
 *
 * @property int $id
 * @property string $name
 * @property string $address
 * @property string $phone_number
 * @property string $user_id
 * @property string $password
 */
class Admin extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'Admin';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['name', 'phone_number', 'user_id', 'password'], 'required'],
            [['name', 'address', 'phone_number', 'user_id', 'password'], 'string', 'max' => 255],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Name',
            'address' => 'Address',
            'phone_number' => 'Phone Number',
            'user_id' => 'User ID',
            'password' => 'Password',
        ];
    }
}
